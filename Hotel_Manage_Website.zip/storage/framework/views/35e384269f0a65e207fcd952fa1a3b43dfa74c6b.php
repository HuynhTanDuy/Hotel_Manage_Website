<section class="section">
      <div class="container">
        <div class="row justify-content-center text-center mb-5">
          <div class="col-md-7">
            <a href="rooms"><h2 class="heading" data-aos="fade-up">Rooms &amp; Suitess</h2></a>
            <p data-aos="fade-up" data-aos-delay="100"><?php echo e($description->room); ?></p>
          </div>
        </div>
        <div class="row">
          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-6 col-lg-4" data-aos="fade-up">
            <a href="rooms" class="room">
              <figure class="img-wrap">
                <img src=<?php echo e($cate->image); ?> alt="Free website template" class="img-fluid mb-3">
              </figure>
              <div class="p-3 text-center room-info">
                <h2><?php echo e($cate->name); ?></h2>
                <span class="text-uppercase letter-spacing-1"><?php echo e($cate->price); ?>$ / per night</span>
              </div>
            </a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          


        </div>
      </div>
    </section>
<?php /* C:\xampp\htdocs\Hotel_Manage_Website\resources\views/layout/rooms.blade.php */ ?>