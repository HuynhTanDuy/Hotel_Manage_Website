<?php $__env->startSection('content'); ?>

<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Room
                            <small>List</small>
                        </h1>
                    </div>
                    <!-- /.col-lg-12 -->
                    <?php if(session('annoucement')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('annoucement')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr align="center">
                                <th>ID</th>
                                <th>Tên phòng</th>
                                <th>Loại phòng</th>
                                <th>Tình trạng</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX" align="center">
                                    <td><?php echo e($r->id); ?></td>
                                    <td><?php echo e($r->name); ?></td>
                                    <td>
                                      <?php if($r->idCategory==1): ?> <?php echo e("Single Room"); ?> <?php endif; ?>
                                      <?php if($r->idCategory==2): ?> <?php echo e("Family Room"); ?> <?php endif; ?>
                                      <?php if($r->idCategory==3): ?>    <?php echo e("Presidential Room"); ?> <?php endif; ?>
                                     
                                    </td>
                                    <td>
                                      <?php if($r->Status==1): ?> <?php echo e("Trống"); ?>

                                      <?php else: ?> <?php echo e("Đã được đặt"); ?>

                                      <?php endif; ?>
                                    </td>
                                   
                                    <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="admin/room/edit/<?php echo e($r->id); ?>">Edit</a></td>
                                    <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="admin/room/delete/<?php echo e($r->id); ?>"> Delete</a></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\Hotel_Manage_Website\resources\views/admin/room/list.blade.php */ ?>