<?php $__env->startSection('content'); ?>

<!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Reservation
                            <small>List</small>
                        </h1>
                    </div>
                    <!-- /.col-lg-12 -->
                    <?php if(session('annoucement')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('annoucement')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr align="center">
                                <th>ID</th>
                                <th>Tên phòng</th>
                                <th>Họ tên khách hàng</th>
                                <th>Số điện thoại</th>
                                <th>Email</th>
                                <th>Ngày đến</th>
                                <th>Ngày đi</th>
                                <th>Số lượng</th>
                                <th>Notes</th>
                                <th>Edit</th>
                                <th>Delete</th>
                                <th>Check bill</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $reservation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="odd gradeX" align="center">
                                    <td><?php echo e($r->id); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($ro->id==$r->idRoom): ?> <?php echo e($ro->name); ?> <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e($r->name); ?></td>
                                    <td><?php echo e($r->phone); ?></td>
                                    <td><?php echo e($r->email); ?></td>
                                    <td><?php echo e($r->DateIn); ?></td>
                                    <td><?php echo e($r->DateOut); ?></td>
                                    <td><?php echo e($r->Numbers); ?></td>
                                    <td><?php echo e($r->Notes); ?></td>
                                   
                                    <td class="center"><i class="fa fa-pencil fa-fw"></i> <a href="admin/reservation/edit/<?php echo e($r->id); ?>">Edit</a></td>
                                    <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="admin/reservation/delete/<?php echo e($r->id); ?>"> Delete</a></td>
                                    <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a href="admin/bill/list/<?php echo e($r->id); ?>"> Check</a></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\Hotel_Manage_Website\resources\views/admin/reservation/list.blade.php */ ?>