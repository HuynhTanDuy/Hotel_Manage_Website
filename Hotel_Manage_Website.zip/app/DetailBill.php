<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailBill extends Model
{
    //
    protected $table="details_bill";
    public $timestamps = true;
    
}
