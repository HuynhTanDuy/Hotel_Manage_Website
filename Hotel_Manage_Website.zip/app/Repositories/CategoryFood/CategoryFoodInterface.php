<?php

namespace App\Repositories\CategoryFood;

interface CategoryFoodInterface
{
    public function GetAll();
}